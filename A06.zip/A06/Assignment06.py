# ------------------------------------------------------------------------------------------ #
# Title: Assignment06
# Desc: This assignment demonstrates using functions with structured error handling
# Change Log: (Nick Tehrani, 8/4/2024, Created Script)
# ------------------------------------------------------------------------------------------ #
import json

# Define the Data Constants
MENU: str = '''
---- Course Registration Program ----
  Select from the following menu:  
    1. Register a Student for a Course.
    2. Show current data.  
    3. Save data to a file.
    4. Exit the program.
----------------------------------------- 
'''
FILE_NAME: str = "Enrollments.json"
FILE_NAME_CSV: str = "Enrollments.csv"

# Define the Data Variables
student_first_name: str = ''  # Holds the first name of a student entered by the user.
student_last_name: str = ''  # Holds the last name of a student entered by the user.
course_name: str = ''  # Holds the name of a course entered by the user.
student_data_row: dict = {}  # Holds one row of student data
students: list = []  # Holds a table of student data
csv_data: str = ''  # Holds combined string data separated by a comma.
file = None  # Holds a reference to an opened file.
menu_choice: str  # Holds the choice made by the user.
error_message: str  # Holds the error message that is passed to function


# ----- Classes and Functions ----- #
class FileProcessor:
    """
    A collection of functions that perform operations such as opening/closing
    or reading/writing files
    """

    @staticmethod
    def read_data_from_file(file_name: str, student_data: list):
        """
        This Function accepts a file name and a list variable as parameters.
        It reads the file and stores the contents in the list variable and returns it.
        If there's an issue with the file, the Function passes in parameters to a
        Function that prints error messages for the user to read.
        """
        global file
        global error_message

        try:
            file = open(file_name, "r")
            student_data = json.load(file)
            file.close()
        except Exception as e:
            error_message = ("Error: There was a problem with READING the file.\n"
                             "Please check that the file exists and that it is in "
                             "a json format.")
            IO.output_error_messages(error_message, e)

        try:
            if file.closed == False:
                file.close()
        except Exception as e:
            error_message = ("Error: There was a problem with CLOSING the file.\n"
                             "Please check that the file exists and that it is in "
                             "a json format.")
            IO.output_error_messages(error_message, e)

        return student_data

    @staticmethod
    def write_data_to_file(file_name: str, student_data: list):
        """
        This Function accepts a file name and a list variable as parameters.
        It writes the values stored in the list variable into the file. The user is
        notified of the Function's actions via printed messages. Next, the Function
        calls on another Function which causes the program to loop back to the beginning.
        If there's an issue with the file, the Function passes in parameters to a
        Function that prints error messages for the user to read.
        """
        global error_message
        global file
        global csv_data

        if ".json" in file_name:
            try:
                file = open(file_name, "w")
                json.dump(student_data, file)
                file.close()
                print("\nThe following data was saved to a file!\n")
                for student in student_data:
                    print(f'Student {student["FirstName"]} '
                          f'{student["LastName"]} is enrolled in {student["CourseName"]}')
            except Exception as e:
                if file.closed == False:
                    file.close()
                error_message = ("Error: There was a problem with writing to the file.\n"
                                 "Please check that the file is not open by another program.")
                IO.output_error_messages(error_message, e)
                IO.input_menu_choice()

        else:
            try:
                file = open(file_name, "w")
                for student in student_data:
                    csv_data = (f'{student["FirstName"]},{student["LastName"]},'
                                f'{student["CourseName"]}\n')
                    file.write(csv_data)
                file.close()

            except Exception as e:
                if file.closed == False:
                    file.close()
                error_message = ("Error: There was a problem with writing to the file.\n"
                                 "Please check that the file is not open by another program.")
                IO.output_error_messages(error_message, e)
                IO.input_menu_choice()


class IO:
    """
    A collection of functions that focus on presenting information to users (output)
    and capturing user input
    """

    # Inputs:
    @staticmethod
    def input_menu_choice():
        """
        This Function prints the value in the MENU constant. Then, it asks the user
        to enter their choice. For each choice, the Function either calls on the
        corresponding Function and updates script variables or performs
        other actions as necessary.
        """
        global menu_choice
        global students

        while True:
            IO.output_menu(MENU)
            menu_choice = input("What would you like to do: ")
            # Input user data
            if menu_choice == "1":
                students = IO.input_student_data(students)
                continue

            # Present the current data
            elif menu_choice == "2":
                IO.output_student_courses(students)
                continue

            # Save the data to a file
            elif menu_choice == "3":
                FileProcessor.write_data_to_file(FILE_NAME, students)
                FileProcessor.write_data_to_file(FILE_NAME_CSV, students)
                continue

            elif menu_choice not in ("1", "2", "3", "4"):
                print("Please only choose option 1, 2, 3, or 4")
                continue

            elif menu_choice == "4":
                break
        print("Program Ended")
        quit()

    @staticmethod
    def input_student_data(student_data: list):
        """
        This Function accepts a list variable as a parameter. It prompts the user to enter
        the first, last, and course names. Then, it stores those values in variables,
        appends the passed in list variable, and returns it. The user is notified via
        printed messages if their actions succeeded. If there's an issue with their entry,
        the Function passes in parameters to a Function that prints error messages
        for the user to read.
        """
        global student_first_name
        global student_last_name
        global course_name
        global student_data_row
        global error_message

        try:
            student_first_name = input("\nEnter the student's first name: ")
            if not student_first_name.isalpha():
                raise ValueError("The first name should not contain numbers.")
            student_last_name = input("Enter the student's last name: ")
            if not student_last_name.isalpha():
                raise ValueError("The last name should not contain numbers.")
            course_name = input("Please enter the name of the course: ")
            student_data_row = {"FirstName": student_first_name,
                                "LastName": student_last_name,
                                "CourseName": course_name}
            student_data.append(student_data_row)
            print(f"You have registered {student_first_name} {student_last_name} for "
                  f"{course_name}.")
        except ValueError as e:
            error_message = e.__str__()
            IO.output_error_messages(error_message, e)
            IO.input_menu_choice()

        except Exception as e:
            error_message = "Error: There was a problem with your entered data."
            IO.output_error_messages(error_message, e)
            IO.input_menu_choice()

        return student_data

    # Outputs:
    @staticmethod
    def output_menu(menu: str):
        """
        This Function accepts a string variable and prints it.
        """
        print(menu)

    @staticmethod
    def output_student_courses(student_data: list):
        """
        This Function accepts a list variable as a parameter and prints the contents
        for the user to read. Next, the Function calls on another Function which
        causes the program to loop back to the beginning.
        """
        print("-" * 50)
        for student in student_data:
            print(f'Student {student["FirstName"]} '
                  f'{student["LastName"]} is enrolled in {student["CourseName"]}')
        print("-" * 50)
        IO.input_menu_choice()

    @staticmethod
    def output_error_messages(message: str, error: Exception = None):
        """
        This Function accepts a string variable and an object variable
        as parameters and prints messages related to them for the user to read.
        """
        print(f"\n{message}")
        print("\n-- Technical Error Message -- ")
        print(error.__doc__)
        print(f"{error.__str__()}\n")


# ----- Main ----- #
students = FileProcessor.read_data_from_file(FILE_NAME, students)
IO.input_menu_choice()
